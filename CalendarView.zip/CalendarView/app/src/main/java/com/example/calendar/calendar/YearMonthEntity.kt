package com.example.calendar.calendar

data class YearMonthEntity(val year: Int, val month: Int) {

}